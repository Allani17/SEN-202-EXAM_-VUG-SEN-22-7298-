package com.example.springbootexam.Model;

import jakarta.persistence.*;
import jakarta.validation.constraints.NotBlank;

@Entity
public class Comment {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    @ManyToOne
    @JoinColumn(name = "orderId", nullable = false)
    private FoodOrder foodOrder;
    @NotBlank(message = "Comment statement must not be blank")
    private String statement;

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public FoodOrder getFoodOrder() {
        return foodOrder;
    }

    public void setFoodOrder(FoodOrder foodOrder) {
        this.foodOrder = foodOrder;
    }

    public @NotBlank(message = "Comment statement must not be blank") String getStatement() {
        return statement;
    }

    public void setStatement(@NotBlank(message = "Comment statement must not be blank") String statement) {
        this.statement = statement;
    }

    public Comment(Long id, FoodOrder foodOrder, String statement) {
        this.id = id;
        this.foodOrder = foodOrder;
        this.statement = statement;
    }

    public Comment() {super();}

    @Override
    public String toString() {
        return "Comment{" +
                "id=" + id +
                ", foodOrder=" + foodOrder +
                ", statement='" + statement + '\'' +
                '}';
    }
}
