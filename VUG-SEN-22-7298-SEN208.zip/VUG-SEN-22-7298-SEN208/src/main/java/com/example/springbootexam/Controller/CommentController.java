package com.example.springbootexam.Controller;

import com.example.springbootexam.Model.*;
import com.example.springbootexam.Repository.*;
import com.example.springbootexam.Service.CommentService;
import com.example.springbootexam.Service.FoodOrderService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.*;

@Controller
public class CommentController {

    @Autowired
    private FoodOrderService foodOrderService;

    @Autowired
    private CommentService commentService;

    @PostMapping("/comment/save")
    public String saveComment(@RequestParam Long orderId, @RequestParam String statement) {
        FoodOrder order = foodOrderService.getOrderById(orderId).orElseThrow();
        Comment comment = new Comment();
        comment.setStatement(statement);
        comment.setFoodOrder(order);
        commentService.saveComment(comment);
        return "redirect:/orders/list";
    }
}
