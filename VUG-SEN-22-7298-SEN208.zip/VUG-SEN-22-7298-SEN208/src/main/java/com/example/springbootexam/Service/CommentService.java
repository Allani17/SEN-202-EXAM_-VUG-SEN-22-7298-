package com.example.springbootexam.Service;

import com.example.springbootexam.Model.Comment;
import com.example.springbootexam.Repository.CommentRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class CommentService {

    @Autowired
    private CommentRepository commentRepository;

    public void saveComment(Comment comment) {
         commentRepository.save(comment);
    }


}
