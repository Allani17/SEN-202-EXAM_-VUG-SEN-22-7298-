package com.example.springbootexam.Repository;

import com.example.springbootexam.Model.FoodOrder;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import java.util.List;

public interface FoodOrderRepository extends JpaRepository<FoodOrder, Long> {
        @Query("SELECT f FROM FoodOrder f WHERE f.foodName LIKE %:keyword%")
        List<FoodOrder> searchByFoodName(@Param("keyword") String keyword);
}