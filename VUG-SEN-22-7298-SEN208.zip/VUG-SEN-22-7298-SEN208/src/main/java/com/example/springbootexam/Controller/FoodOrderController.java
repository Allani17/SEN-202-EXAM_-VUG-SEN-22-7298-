package com.example.springbootexam.Controller;

import com.example.springbootexam.Model.FoodOrder;
import com.example.springbootexam.Service.FoodOrderService;
import jakarta.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.*;
import org.springframework.data.web.PageableDefault;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.*;

@Controller
@RequestMapping("/orders")
public class FoodOrderController {

    @Autowired
    private FoodOrderService foodOrderService;

    @GetMapping("/list")
    public String listOrders(@RequestParam(defaultValue = "0") int page, Model model) {
        Page<FoodOrder> orders = foodOrderService.getPaginatedOrders(page, 5); // ✅ 5 per page
        model.addAttribute("foodOrders", orders);
        model.addAttribute("currentPage", page);
        return "order_list";
    }

    @GetMapping("/new")
    public String showOrderForm(Model model) {
        model.addAttribute("foodOrder", new FoodOrder());
        return "orderForm";
    }

    @PostMapping
    public String placeOrder(@Valid @ModelAttribute FoodOrder foodOrder, BindingResult result) {
        if (result.hasErrors()) {
            return "orderForm";
        }
        foodOrderService.save(foodOrder);
        return "redirect:/orders/list";
    }
}
