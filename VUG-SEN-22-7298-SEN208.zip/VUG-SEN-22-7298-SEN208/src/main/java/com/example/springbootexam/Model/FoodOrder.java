package com.example.springbootexam.Model;

import jakarta.persistence.*;
import jakarta.validation.constraints.*;
import java.time.LocalDateTime;
import java.util.*;

@Entity
public class FoodOrder {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private long id;

    @NotBlank(message = "Food name must not be blank")
    @Size(min = 3, max = 20)
    private String foodName;

    @NotBlank(message = "Username must not be blank")
    @Size(min = 3, max = 20)
    private String userName;

    @Min(100)
    private double price;

    private LocalDateTime orderTime = LocalDateTime.now();

    @OneToMany(mappedBy = "foodOrder", cascade = CascadeType.ALL)
    private List<Comment> comments;

    public long getId() {
        return id;
    }

    public void setId(long id) {
        this.id = id;
    }

    public @NotBlank(message = "Food name must not be blank") @Size(min = 3, max = 20) String getFoodName() {
        return foodName;
    }

    public void setFoodName(@NotBlank(message = "Food name must not be blank") @Size(min = 3, max = 20) String foodName) {
        this.foodName = foodName;
    }

    public @NotBlank(message = "Username must not be blank") @Size(min = 3, max = 20) String getUserName() {
        return userName;
    }

    public void setUserName(@NotBlank(message = "Username must not be blank") @Size(min = 3, max = 20) String userName) {
        this.userName = userName;
    }

    @Min(100)
    public double getPrice() {
        return price;
    }

    public void setPrice(@Min(100) double price) {
        this.price = price;
    }

    public LocalDateTime getOrderTime() {
        return orderTime;
    }

    public void setOrderTime(LocalDateTime orderTime) {
        this.orderTime = orderTime;
    }

    public List<Comment> getComments() {
        return comments;
    }

    public void setComments(List<Comment> comments) {
        this.comments = comments;
    }


    public FoodOrder(Long id, String foodName, String userName, Double price, LocalDateTime orderTime, List<Comment> comments ) {
        this.id =id;
        this.foodName =foodName;
        this.userName =userName;
        this.price =price;
        this.orderTime =orderTime;
        this.comments =comments;
    }

    public FoodOrder() {}

    @Override
    public String toString() {
        return "FoodOrder{" +
                "id=" + id +
                ", foodName='" + foodName + '\'' +
                ", userName='" + userName + '\'' +
                ", price=" + price +
                ", orderTime=" + orderTime +
                ", comments=" + comments +
                '}';
    }
}
