package com.example.springbootexam.Service;

import com.example.springbootexam.Model.FoodOrder;
import com.example.springbootexam.Repository.FoodOrderRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class FoodOrderService {

    @Autowired
    private FoodOrderRepository foodOrderRepository;

    public Page<FoodOrder> getPaginatedOrders(int page, int size) {
        return foodOrderRepository.findAll(PageRequest.of(page, size));
    }

    public List<FoodOrder> searchByKeyword(String keyword) {
        return foodOrderRepository.searchByFoodName(keyword);
    }

    public FoodOrder save(FoodOrder foodOrder) {
        return foodOrderRepository.save(foodOrder);
    }

    public Optional<FoodOrder> getOrderById(Long id) {
        return foodOrderRepository.findById(id);
    }
}
