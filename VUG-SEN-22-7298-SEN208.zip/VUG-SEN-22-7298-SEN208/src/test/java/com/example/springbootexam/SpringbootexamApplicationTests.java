package com.example.springbootexam;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringbootexamApplicationTests {

	@Test
	void contextLoads() {
	}

}
